"use strict";

/**
 * dashboard.js
 *
 * Phase 5 scope: dashboard UI, settings persistence, demo mode, and
 * message-passing hooks toward the service worker.
 *
 * NOTE: message.type strings below are duplicated locally for now.
 * Phase 6 introduces src/shared/constants.js and src/shared/messages.js;
 * once that lands, these local MSG constants will be replaced with an
 * import from that shared module so both sides of the message channel
 * stay in sync from a single source of truth.
 */

const MSG = {
  START_EXTRACTION: "START_EXTRACTION",
  STOP_EXTRACTION: "STOP_EXTRACTION",
  GET_SETTINGS: "GET_SETTINGS",
  SAVE_SETTINGS: "SAVE_SETTINGS",
  EXPORT_CSV: "EXPORT_CSV",
  EXPORT_XLSX: "EXPORT_XLSX",
  // Inbound (from service worker)
  RESULT_BATCH: "RESULT_BATCH",
  EXTRACTION_PROGRESS: "EXTRACTION_PROGRESS",
  EXTRACTION_STARTED: "EXTRACTION_STARTED",
  EXTRACTION_COMPLETED: "EXTRACTION_COMPLETED",
  EXTRACTION_ERROR: "EXTRACTION_ERROR",
};

// Platform capability map — mirrors Phase 42's platformCapabilities design.
// Facebook ships disabled in V1; this is surfaced in the UI, never hidden.
const PLATFORM_CAPABILITIES = {
  youtube: { label: "SUPPORTED", enabled: true },
  instagram: { label: "PARTIALLY SUPPORTED — public browser context only", enabled: true },
  x: { label: "SUPPORTED", enabled: true },
  facebook: { label: "LIMITED BY PLATFORM", enabled: false },
  reddit: { label: "SUPPORTED", enabled: true },
};

const REGION_SUPPORT = {
  india: "Partially supported — used as a search-query modifier, not verified geographic origin.",
  asia: "Partially supported — broad query modifier only.",
  usa: "Partially supported — broad query modifier only.",
  europe: "Not supported — no reliable public query modifier; used as a label only.",
  uk: "Partially supported — used as a search-query modifier only.",
  middle_east: "Not supported — no reliable public query modifier; used as a label only.",
  global: "Not applicable — no region filter is applied.",
  custom: "Depends on the custom term you provide; treated as a plain search-query modifier.",
};

const state = {
  results: [],       // normalized records currently in the table
  filterText: "",
  extraction: {
    status: "IDLE",  // IDLE | INITIALIZING | SEARCHING | EXTRACTING | SCROLLING | PROCESSING | STOPPING | COMPLETED | ERROR
    discovered: 0,
    valid: 0,
    duplicates: 0,
    errors: 0,
    startedAt: null,
    limit: 100,
  },
  elapsedTimerId: null,
};

// ---------- DOM refs ----------
const el = {
  connectionDot: document.getElementById("connectionDot"),
  connectionText: document.getElementById("connectionText"),
  statTotal: document.getElementById("statTotal"),
  statPlatform: document.getElementById("statPlatform"),
  statExtracted: document.getElementById("statExtracted"),
  statSpeed: document.getElementById("statSpeed"),
  platformSelect: document.getElementById("platformSelect"),
  platformCapabilityHint: document.getElementById("platformCapabilityHint"),
  keywordInput: document.getElementById("keywordInput"),
  limitSelect: document.getElementById("limitSelect"),
  regionSelect: document.getElementById("regionSelect"),
  regionSupportHint: document.getElementById("regionSupportHint"),
  demoModeToggle: document.getElementById("demoModeToggle"),
  startBtn: document.getElementById("startBtn"),
  stopBtn: document.getElementById("stopBtn"),
  clearBtn: document.getElementById("clearBtn"),
  statusBadge: document.getElementById("statusBadge"),
  elapsedTime: document.getElementById("elapsedTime"),
  progressBarTrack: document.getElementById("progressBarTrack"),
  progressBarFill: document.getElementById("progressBarFill"),
  statDiscovered: document.getElementById("statDiscovered"),
  statValid: document.getElementById("statValid"),
  statDuplicates: document.getElementById("statDuplicates"),
  statErrors: document.getElementById("statErrors"),
  viewLogsBtn: document.getElementById("viewLogsBtn"),
  logsPanel: document.getElementById("logsPanel"),
  logsOutput: document.getElementById("logsOutput"),
  tableSearch: document.getElementById("tableSearch"),
  resultsTableBody: document.getElementById("resultsTableBody"),
  exportCsvBtn: document.getElementById("exportCsvBtn"),
  exportXlsxBtn: document.getElementById("exportXlsxBtn"),
};

// ---------- Init ----------
document.addEventListener("DOMContentLoaded", init);

async function init() {
  bindEvents();
  await loadSettings();
  updatePlatformHint();
  updateRegionHint();
  renderConnectionStatus();
  wireRuntimeMessages();
  log("INFO", "Dashboard initialized");
}

function bindEvents() {
  el.platformSelect.addEventListener("change", () => {
    updatePlatformHint();
    persistSettings();
  });
  el.regionSelect.addEventListener("change", () => {
    updateRegionHint();
    persistSettings();
  });
  el.keywordInput.addEventListener("input", debounce(persistSettings, 400));
  el.limitSelect.addEventListener("change", persistSettings);
  el.demoModeToggle.addEventListener("change", persistSettings);

  el.startBtn.addEventListener("click", onStartClicked);
  el.stopBtn.addEventListener("click", onStopClicked);
  el.clearBtn.addEventListener("click", onClearClicked);

  el.viewLogsBtn.addEventListener("click", () => {
    el.logsPanel.hidden = !el.logsPanel.hidden;
  });

  el.tableSearch.addEventListener("input", debounce((e) => {
    state.filterText = e.target.value.trim().toLowerCase();
    renderTable();
  }, 150));

  el.exportCsvBtn.addEventListener("click", onExportCsv);
  el.exportXlsxBtn.addEventListener("click", onExportXlsx);
}

// ---------- Settings ----------
async function loadSettings() {
  const defaults = {
    platform: "youtube",
    keyword: "",
    limit: "100",
    region: "india",
    demoMode: true, // default ON until Phase 6-9 land, so the UI is testable now
  };
  const settings = await getStorage("settings", defaults);
  el.platformSelect.value = settings.platform;
  el.keywordInput.value = settings.keyword;
  el.limitSelect.value = settings.limit;
  el.regionSelect.value = settings.region;
  el.demoModeToggle.checked = settings.demoMode;
}

function persistSettings() {
  const settings = {
    platform: el.platformSelect.value,
    keyword: el.keywordInput.value,
    limit: el.limitSelect.value,
    region: el.regionSelect.value,
    demoMode: el.demoModeToggle.checked,
  };
  setStorage("settings", settings);
}

// ---------- Platform / region hints ----------
function updatePlatformHint() {
  const cap = PLATFORM_CAPABILITIES[el.platformSelect.value];
  el.platformCapabilityHint.textContent = cap.label;
  el.startBtn.disabled = !cap.enabled && !el.demoModeToggle.checked;
  el.statPlatform.textContent = platformLabel(el.platformSelect.value);
}

function updateRegionHint() {
  const text = REGION_SUPPORT[el.regionSelect.value] || "Support unknown for this region.";
  el.regionSupportHint.innerHTML = `Region filtering: <strong>${text}</strong>`;
}

function platformLabel(value) {
  return { youtube: "YouTube", instagram: "Instagram", x: "X / Twitter", facebook: "Facebook", reddit: "Reddit" }[value] || value;
}

// ---------- Keyword parsing (Step 3 requirement) ----------
function parseKeywords(raw) {
  const parts = raw.split(",").map((k) => k.trim()).filter(Boolean);
  return Array.from(new Set(parts.map((k) => k.toLowerCase()))).map((lower) => {
    // preserve original casing of the first occurrence
    return parts.find((p) => p.toLowerCase() === lower);
  });
}

// ---------- Start / Stop / Clear ----------
async function onStartClicked() {
  const keywords = parseKeywords(el.keywordInput.value);
  if (keywords.length === 0) {
    log("WARN", "Start blocked: no keyword/hashtag entered");
    alert("Enter at least one keyword or hashtag.");
    return;
  }

  const config = {
    platform: el.platformSelect.value,
    keywords,
    limit: el.limitSelect.value === "unlimited" ? "unlimited" : parseInt(el.limitSelect.value, 10),
    region: el.regionSelect.value,
    demoMode: el.demoModeToggle.checked,
  };

  state.extraction.limit = config.limit;
  setExtractionStatus("INITIALIZING");
  el.startBtn.disabled = true;
  el.stopBtn.disabled = false;
  startElapsedTimer();

  log("INFO", `Extraction requested: platform=${config.platform} keywords=${JSON.stringify(config.keywords)} limit=${config.limit} region=${config.region} demoMode=${config.demoMode}`);

  if (config.demoMode) {
    runDemoExtraction(config);
    return;
  }

  // Real extraction path — service worker is introduced in Phase 6.
  // The call is wired now so no further changes are needed to this file later.
  try {
    await sendRuntimeMessage({ type: MSG.START_EXTRACTION, payload: config });
  } catch (err) {
    log("ERROR", `Could not reach service worker: ${err.message}. (Expected until Phase 6 background is added.)`);
    setExtractionStatus("ERROR");
    resetControls();
  }
}

async function onStopClicked() {
  setExtractionStatus("STOPPING");
  log("INFO", "Stop requested");
  try {
    await sendRuntimeMessage({ type: MSG.STOP_EXTRACTION });
  } catch (err) {
    log("WARN", `Stop message not delivered (no active background yet): ${err.message}`);
  }
  finishExtraction("IDLE");
}

function onClearClicked() {
  state.results = [];
  state.extraction = { status: "IDLE", discovered: 0, valid: 0, duplicates: 0, errors: 0, startedAt: null, limit: state.extraction.limit };
  renderTable();
  renderProgress();
  setExtractionStatus("IDLE");
  stopElapsedTimer();
  el.elapsedTime.textContent = "00:00:00";
  log("INFO", "Cleared results and reset state");
}

function resetControls() {
  el.startBtn.disabled = !PLATFORM_CAPABILITIES[el.platformSelect.value].enabled && !el.demoModeToggle.checked;
  el.stopBtn.disabled = true;
  stopElapsedTimer();
}

function finishExtraction(finalStatus) {
  setExtractionStatus(finalStatus);
  resetControls();
}

// ---------- Demo mode (Phase 39 requirement) ----------
function runDemoExtraction(config) {
  setExtractionStatus("SEARCHING");
  const total = config.limit === "unlimited" ? 25 : Math.min(config.limit, 25);
  let produced = 0;

  const interval = setInterval(() => {
    if (produced >= total) {
      clearInterval(interval);
      finishExtraction("COMPLETED");
      log("INFO", `Demo extraction completed: ${state.results.length} records`);
      return;
    }
    setExtractionStatus(produced === 0 ? "EXTRACTING" : "SCROLLING");
    const batch = generateMockRecords(config, 3);
    ingestRecords(batch);
    produced += batch.length;
  }, 350);
}

function generateMockRecords(config, count) {
  const platform = config.platform;
  const kw = config.keywords[0] || "scam";
  const now = new Date().toISOString();
  const out = [];
  for (let i = 0; i < count; i++) {
    const n = state.results.length + out.length + 1;
    out.push({
      id: `${platform}-demo-${n}-${Date.now()}`,
      platform,
      caption: `[Demo] Beware of ${kw} — sample post #${n}`,
      url: `https://example.com/${platform}/demo-post-${n}`,
      normalizedUrl: `https://example.com/${platform}/demo-post-${n}`,
      keywords: config.keywords,
      hashtags: config.keywords.filter((k) => k.startsWith("#")),
      author: `demo_user_${n}`,
      authorUrl: "",
      publishedAt: now,
      collectedAt: now,
      mediaType: "post",
      extractionSource: "demo",
      region: config.region,
      status: "valid",
      error: "",
    });
  }
  return out;
}

// ---------- Ingest / dedupe (client-side, mirrors Phase 9 manager logic) ----------
function ingestRecords(batch) {
  state.extraction.discovered += batch.length;
  const existingUrls = new Set(state.results.map((r) => r.normalizedUrl));
  let added = 0;
  for (const rec of batch) {
    if (existingUrls.has(rec.normalizedUrl)) {
      state.extraction.duplicates += 1;
      continue;
    }
    existingUrls.add(rec.normalizedUrl);
    state.results.push(rec);
    added += 1;
  }
  state.extraction.valid += added;
  renderTable();
  renderProgress();
  renderSummaryCards();
}

// ---------- Runtime messages from service worker ----------
function wireRuntimeMessages() {
  if (!chrome?.runtime?.onMessage) return;
  chrome.runtime.onMessage.addListener((message) => {
    switch (message?.type) {
      case MSG.RESULT_BATCH:
        ingestRecords(message.payload.results);
        break;
      case MSG.EXTRACTION_PROGRESS:
        Object.assign(state.extraction, message.payload);
        renderProgress();
        break;
      case MSG.EXTRACTION_STARTED:
        setExtractionStatus("EXTRACTING");
        break;
      case MSG.EXTRACTION_COMPLETED:
        finishExtraction("COMPLETED");
        break;
      case MSG.EXTRACTION_ERROR:
        log("ERROR", message.payload?.message || "Unknown extraction error");
        finishExtraction("ERROR");
        break;
      default:
        break;
    }
  });
}

// ---------- Rendering ----------
function setExtractionStatus(status) {
  state.extraction.status = status;
  el.statusBadge.textContent = status;
  el.statusBadge.className = "badge " + ({
    EXTRACTING: "badge--active", SEARCHING: "badge--active", SCROLLING: "badge--active",
    COMPLETED: "badge--success", ERROR: "badge--error",
  }[status] || "");
  renderConnectionStatus();
}

function renderConnectionStatus() {
  const active = ["INITIALIZING", "SEARCHING", "EXTRACTING", "SCROLLING", "PROCESSING", "STOPPING"].includes(state.extraction.status);
  const errored = state.extraction.status === "ERROR";
  el.connectionDot.className = "status-dot " + (errored ? "status-dot--error" : active ? "status-dot--active" : "status-dot--idle");
  el.connectionText.textContent = errored ? "Error" : active ? "Extraction running" : "Idle";
}

function renderProgress() {
  const { discovered, valid, duplicates, errors, limit } = state.extraction;
  el.statDiscovered.textContent = discovered;
  el.statValid.textContent = valid;
  el.statDuplicates.textContent = duplicates;
  el.statErrors.textContent = errors;

  if (limit === "unlimited") {
    el.progressBarTrack.classList.add("indeterminate");
    el.progressBarFill.style.width = "";
    el.progressBarTrack.setAttribute("aria-valuenow", "0");
  } else {
    el.progressBarTrack.classList.remove("indeterminate");
    const pct = limit > 0 ? Math.min(100, Math.round((valid / limit) * 100)) : 0;
    el.progressBarFill.style.width = pct + "%";
    el.progressBarTrack.setAttribute("aria-valuenow", String(pct));
  }
}

function renderSummaryCards() {
  el.statTotal.textContent = state.results.length;
  el.statExtracted.textContent = state.extraction.valid;
  if (state.extraction.startedAt) {
    const minutes = Math.max((Date.now() - state.extraction.startedAt) / 60000, 1 / 60);
    el.statSpeed.textContent = (state.extraction.valid / minutes).toFixed(1) + "/min";
  }
}

function renderTable() {
  const rows = state.filterText
    ? state.results.filter((r) => matchesFilter(r, state.filterText))
    : state.results;

  if (rows.length === 0) {
    el.resultsTableBody.innerHTML =
      `<tr class="empty-row"><td colspan="7">${state.results.length === 0 ? "No results yet. Configure extraction above and press Start." : "No results match your filter."}</td></tr>`;
    return;
  }

  const frag = document.createDocumentFragment();
  rows.forEach((r, idx) => {
    const tr = document.createElement("tr");

    tr.appendChild(td(String(idx + 1)));
    tr.appendChild(td(r.caption, true));

    const urlTd = document.createElement("td");
    urlTd.className = "url-cell";
    const a = document.createElement("a");
    a.href = r.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.textContent = truncate(r.url, 40);
    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "copy-url-btn";
    copyBtn.textContent = "copy";
    copyBtn.addEventListener("click", () => navigator.clipboard.writeText(r.url));
    urlTd.append(a, copyBtn);
    tr.appendChild(urlTd);

    tr.appendChild(td([...(r.hashtags || []), ...(r.keywords || [])].filter((v, i, arr) => arr.indexOf(v) === i).join(" ")));
    tr.appendChild(td(platformLabel(r.platform)));
    tr.appendChild(td(formatDate(r.collectedAt)));

    const statusTd = document.createElement("td");
    const pill = document.createElement("span");
    pill.className = "status-pill " + (r.status === "error" ? "status-pill--error" : "status-pill--valid");
    pill.textContent = r.status || "valid";
    statusTd.appendChild(pill);
    tr.appendChild(statusTd);

    frag.appendChild(tr);
  });

  el.resultsTableBody.innerHTML = "";
  el.resultsTableBody.appendChild(frag);
}

function td(text, useTextContent = false) {
  const cell = document.createElement("td");
  if (useTextContent) cell.textContent = text;
  else cell.textContent = text; // always textContent — never innerHTML with scraped content (Phase 25)
  return cell;
}

function matchesFilter(record, filterLower) {
  return (record.caption || "").toLowerCase().includes(filterLower)
    || (record.url || "").toLowerCase().includes(filterLower)
    || (record.author || "").toLowerCase().includes(filterLower)
    || [...(record.hashtags || []), ...(record.keywords || [])].some((k) => k.toLowerCase().includes(filterLower));
}

// ---------- Export ----------
// Full CSV/XLSX exporter modules land in Phase 9 (src/export/). This handler
// already works standalone for demo-mode testing using a minimal inline CSV
// builder; it will be replaced with a call to EXPORT_CSV via the service
// worker once storage-manager/export-manager exist, so large (IndexedDB-backed)
// result sets export correctly too.
function onExportCsv() {
  if (state.results.length === 0) {
    alert("No results to export yet.");
    return;
  }
  const headers = ["#", "Platform", "Caption", "URL", "Keywords/Hashtags", "Author", "Date", "Collected At"];
  const rows = state.results.map((r, i) => [
    i + 1, r.platform, r.caption, r.url,
    [...(r.hashtags || []), ...(r.keywords || [])].join(" "),
    r.author, r.publishedAt, r.collectedAt,
  ]);
  const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(",")).join("\r\n");
  downloadTextFile(csv, `research-export-${timestampForFilename()}.csv`, "text/csv;charset=utf-8;");
  log("INFO", `Exported ${state.results.length} records to CSV`);
}

function onExportXlsx() {
  log("WARN", "XLSX export requires the bundled XLSX library added in Phase 9 — not available yet in this build. Use Export CSV for now.");
  alert("XLSX export ships in Phase 9. Use Export CSV for now.");
}

function csvEscape(value) {
  const str = String(value ?? "");
  if (/[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function downloadTextFile(content, filename, mime) {
  // BOM prefix ensures Excel opens UTF-8 (Unicode hashtags, Hindi text) correctly.
  const blob = new Blob(["\ufeff" + content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function timestampForFilename() {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

// ---------- Utilities ----------
function truncate(str, max) {
  return str.length > max ? str.slice(0, max - 1) + "…" : str;
}

function formatDate(iso) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

function log(level, message) {
  const line = `[${new Date().toLocaleTimeString()}] [${level}] ${message}`;
  el.logsOutput.textContent += line + "\n";
  el.logsOutput.scrollTop = el.logsOutput.scrollHeight;
}

function startElapsedTimer() {
  state.extraction.startedAt = Date.now();
  stopElapsedTimer();
  state.elapsedTimerId = setInterval(() => {
    const secs = Math.floor((Date.now() - state.extraction.startedAt) / 1000);
    const h = String(Math.floor(secs / 3600)).padStart(2, "0");
    const m = String(Math.floor((secs % 3600) / 60)).padStart(2, "0");
    const s = String(secs % 60).padStart(2, "0");
    el.elapsedTime.textContent = `${h}:${m}:${s}`;
    renderSummaryCards();
  }, 1000);
}

function stopElapsedTimer() {
  if (state.elapsedTimerId) {
    clearInterval(state.elapsedTimerId);
    state.elapsedTimerId = null;
  }
}

// ---------- chrome.storage / chrome.runtime helpers ----------
function getStorage(key, fallback) {
  return new Promise((resolve) => {
    if (!chrome?.storage?.local) { resolve(fallback); return; }
    chrome.storage.local.get([key], (res) => {
      resolve(res?.[key] ?? fallback);
    });
  });
}

function setStorage(key, value) {
  if (!chrome?.storage?.local) return;
  chrome.storage.local.set({ [key]: value });
}

function sendRuntimeMessage(message) {
  return new Promise((resolve, reject) => {
    if (!chrome?.runtime?.sendMessage) { reject(new Error("chrome.runtime unavailable")); return; }
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(response);
    });
  });
}
